function on(){
  var txt;
var r = confirm("ARE YOU SURE TRANFER MONEY");
if (r == true) 
{
  return true;
} else {
  return false;
}
}
    


